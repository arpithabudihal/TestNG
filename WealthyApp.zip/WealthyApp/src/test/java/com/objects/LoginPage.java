package com.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	By LoginLink = By.linkText("Login via email/username");
	By EmailID = By.id("id_email");
	By Password = By.id("id_password");
	By CaptchaFrame = By.xpath("//*[@title='reCAPTCHA']");
	By CaptchaAnchor = By.id("recaptcha-anchor");
	By LoginBTN = By.className("login-btn");


	public void CheckLogin(String username,String password) {
		try {
			driver.findElement(LoginLink).click();
			driver.findElement(EmailID).sendKeys(username);
			driver.findElement(Password).sendKeys(password);
			driver.switchTo().frame(driver.findElement(CaptchaFrame));
			driver.findElement(CaptchaAnchor).click();
			System.out.println("click on robot");
			driver.switchTo().defaultContent();
			Thread.sleep(20000);
			driver.findElement(By.className("login-btn")).click();

			Thread.sleep(2000);
		} catch(Exception e) {
			System.out.println("Exception Caught"+ e.getMessage());
		}
	}
}
