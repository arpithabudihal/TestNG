package com.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.objects.LoginPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Login {

	WebDriver driver;

	@BeforeTest
	public void Setup() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://api.buildwealth.in/dashboards/login/");
	}

	@Test
	public void PostiveLogin() {
		LoginPage page = new LoginPage(driver);
		page.CheckLogin("siddharth.mewada@wealthy.in", "Sid@wealthy");
	}

	@AfterTest
	public void TearDown() {
		driver.close();
	}

}
