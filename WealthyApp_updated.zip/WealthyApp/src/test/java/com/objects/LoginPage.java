package com.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	By LoginLink = By.linkText("Login via email/username");
	By EmailID = By.id("id_email");
	By Password = By.id("id_password");
	By CaptchaFrame = By.xpath("//*[@title='reCAPTCHA']");
	By CaptchaAnchor = By.id("recaptcha-anchor");
	By LoginBTN = By.className("login-btn");
	By StoreLink = By.className("store-link");
	By FD = By.linkText("Fixed Deposits");
	By TenureEdit = By.cssSelector("img[alt='Edit']");
	By Tenure = By.xpath("//input[@max='60']");
	By GenderF = By.xpath("//img[@alt='Female']");
	By SCYes = By.xpath("//div[contains(text(),'Yes')]"); //Yes,No
	By ProviderPNB = By.xpath("//label[@class='fd-chart-item ' and @for='PNBHousing']"); //PNBHousing,ShriramFD,BajajFD,ICICIHousing
	By ContinueBTN = By.xpath("//div[@class='ws-continue-button']");



	public void CheckLogin(String username,String password) {
		try {
			driver.findElement(LoginLink).click();
			driver.findElement(EmailID).sendKeys(username);
			driver.findElement(Password).sendKeys(password);
			driver.switchTo().frame(driver.findElement(CaptchaFrame));
			driver.findElement(CaptchaAnchor).click();
			System.out.println("click on robot");
			driver.switchTo().defaultContent();
			Thread.sleep(20000);
			driver.findElement(By.className("login-btn")).click();

			Thread.sleep(2000);
		} catch(Exception e) {
			System.out.println("Exception Caught"+ e.getMessage());
		}
	}
		
	public void SetFDCalculator(String period) {
		try {
			driver.findElement(StoreLink).click();
			Thread.sleep(1000);
			driver.findElement(FD).click();
			Thread.sleep(1000);
			driver.findElement(TenureEdit).click();
			Thread.sleep(2000);
			driver.findElement(Tenure).clear();
			Thread.sleep(2000);
			driver.findElement(Tenure).sendKeys(period);
			Thread.sleep(1000);
			driver.findElement(GenderF).click();
			Thread.sleep(1000);
			driver.findElement(SCYes).click();
			Thread.sleep(1000);
			driver.findElement(ProviderPNB).click();
			Thread.sleep(1000);
			driver.findElement(ContinueBTN).click();
			Thread.sleep(1000);
			
		}catch(Exception e) {
			System.out.println("Exception Caught"+ e.getMessage());
		}
	
	}
}
