package com.tests;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import com.objects.LoginPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Login {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentSparkReporter spark;
	ExtentTest extentTest;
	
	
	@BeforeSuite
	public void SuiteSetup() {
		extent = new ExtentReports();
//		spark = new ExtentSparkReporter("target/Spark.html");
		spark = new ExtentSparkReporter(System.getProperty("user.dir")+"/test-output/spark.html");
		extent.attachReporter(spark);
//		extent.createTest("MyFirstTest")
//		  .log(Status.PASS, "This is a logging event for MyFirstTest, and it passed!");
//		extent.flush();

	}


	
	@BeforeTest
	public void Setup() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions option = new ChromeOptions();
		option.setExperimentalOption("debuggerAddress", "localhost:9022");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://api.buildwealth.in/dashboards/login/");
	}

	@Test
	public void PostiveLogin() {
//		extent.createTest("TC-1-Login");
		extentTest = extent.createTest("TC-1-Login").createNode("Login").pass("Pass");
		LoginPage page = new LoginPage(driver);
		page.CheckLogin("siddharth.mewada@wealthy.in", "Sid@wealthy");
		
		ExtentTest node = extent.createTest("TC-1-Login").createNode("Login").pass("Pass");
	}
	
	@Test
	public void FDCalculatorEntry() {
		extentTest = extent.createTest("TC-2-Enter FD Calculator Details").createNode("FD Calculator");
		LoginPage page = new LoginPage(driver);
		page.CheckLogin("siddharth.mewada@wealthy.in", "Sid@wealthy");
		page.SetFDCalculator("24");
		ExtentTest node = extent.createTest("TC-2-Enter FD Calculator Details").createNode("FD Calculator").pass("Pass");
	}

	
	
	
	
	@AfterTest
	public void TearDown() {
		driver.close();
		extent.flush();
	
	}

}
